<?php
include 'includes/header.php';
// include 'includes/config.php';


?>
<?php
if (isset($_POST['about_us_page'])) {
    if ($_FILES['img']['name'] != "") {

        $img_res = mysqli_query($conn, 'SELECT * FROM tbl_footer_setting WHERE id=1');
        $img_res_row = mysqli_fetch_assoc($img_res);

        if ($img_res_row['img'] != "") {
            unlink('images/about-us/' . $img_res_row['img']);
        }

        $img = "about-" . rand(0, 99999) . "_" . $_FILES['img']['name'];
        $tpath1 = 'images/about-us/' . $img;
        move_uploaded_file($_FILES["img"]["tmp_name"], $tpath1);

        $data = array(
            'title'  =>  $_POST['title'],
            'small_title'  =>  $_POST['small_title'],
            'image'   =>  $img,
            'alt_tag'  =>  $_POST['alt_tag'],
            'description'  =>  addslashes($_POST['description'])
        );
    } else {
        $data = array(
            'title'  =>  $_POST['title'],
            'small_title'  =>  $_POST['small_title'],
            'alt_tag'  =>  $_POST['alt_tag'],
            'description'  =>  addslashes($_POST['description'])
        );
    }

    $settings_edit = Update('tbl_about_us', $data, "WHERE id=1");

    if ($settings_edit) {
        echo "<script type='text/javascript'>alert('Updated!');</script>";
        echo '<script>window.location.href = "about-us.php";</script>';
    } else {
        echo "<script type='text/javascript'>alert('Something went!');</script>";
        echo '<script>window.location.href = "about-us.php";</script>';
    }
}


?>
<!--add-employees -->
<!-- include 'includes/side-bar.php';-->
<?php
$select = "SELECT * FROM tbl_footer_setting WHERE id = 1";
$result = mysqli_query($conn, $select);
$row = mysqli_fetch_assoc($result);
?>
<nav class="sidebar">
    <div class="logo d-flex justify-content-between">
        <a href="index.html"><img src="./images/footer/<?php echo $row['logo']; ?>" height="70" width="70" alt="<?php echo $row['alt_tag']; ?>"></a>
        <div class="sidebar_close_icon d-lg-none">
            <i class="ti-close"></i>
        </div>
    </div>
    <ul id="sidebar_menu">
            <li class="">
            <a class="" href="home.php" aria-expanded="false">

                <img src="assets/img/menu-icon/1.svg" alt>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>Home</span>
            </a>
            <ul>
               <li><a href="manage-banner.php">Banner</a></li>
               <li><a href="manage-extra.php">Extra</a></li>
            </ul>
        </li>


        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>Home</span>
            </a>
            <ul>
               <li><a href="manage-banner.php">Banner</a></li>
               <li><a href="manage-extra.php">Extra</a></li>
            </ul>
        </li>

        <li class="mm-active">
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>About Us</span>
            </a>
            <ul>
                <li><a href="about-us.php" class="active">About Us</a></li>
               <li><a href="mission-vission-goal.php">Mission,Vission,Goals</a></li>
                <li><a href="Team.php">Team</a></li>
            </ul>
        </li>

        
        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>Buyer Section</span>
            </a>
            <ul>
               <li><a href="buyer-benefits.php">Benefits</a></li>
               <li><a href="buyer-whychoose.php">Why Choose us</a></li>
            </ul>
        </li>

        <li class>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>Supplier Section</span>
            </a>
            <ul>
              <li><a href="supplier-benefits.php">Benefits</a></li>
               <li><a href="supplier-whychoose.php">Why choose us</a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fa fa-users"></i>
                <span>Manage Employee</span>
            </a>
            <ul>
                <li><a href="manage-employee.php">Employees</a></li>
                <li><a href="manage-department.php">Departments</a></li>
                <li><a href="manage-role.php">Roles</a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-box"></i>
                <span>Manage Products</span>
            </a>
            <ul>
                <li><a href="manage-category.php">Categorys</a></li>
                <!-- <li><a href="manage-department.php">Sub-Categorys</a></li> -->
                <li><a href="manage-product.php">Products</a></li>
            </ul>
        </li>
        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-truck"></i>
                <span>Manage Supplier</span>
            </a>
            <ul>
                <li><a href="manage-supplier.php">Supplier</a></li>
                <li><a href="supplier-product.php">Product</a></li>
            </ul>
        </li>
        <li class>
            <a class="" href="manage-customer.php" aria-expanded="false">
                <i class="fa fa-users"></i>
                <span>Manage Customer</span>
            </a>
            <!-- <ul>
                <li><a href="mail_box.html">Mail Box</a></li>
                <li><a href="chat.html">Chat</a></li>
                <li><a href="faq.html">FAQ</a></li>
            </ul> -->
        </li>
        <li class>
            <a class="" href="manage-inquiry.php" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>Manage Inquiry</span>
            </a>
            <!-- <ul>
                <li><a href="mail_box.html">Mail Box</a></li>
                <li><a href="chat.html">Chat</a></li>
                <li><a href="faq.html">FAQ</a></li>
            </ul> -->
        </li>
        
        <li class>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-address-book"></i>
                <span>Manage FAQs</span>
            </a>
            <ul>
                <li><a href="faqs-customer.php">Customer FAQs</a></li>
                <li><a href="faqs-supplier.php">Supplier FAQs</a></li>
            </ul>
        </li>
          <li class="">
            <a class="" href="contact-us-setting.php" aria-expanded="false">
                <i class="fas fa-address-book"></i>
                <span>Contact Us</span>
            </a>
            <!-- <ul>
                <li><a href="mail_box.html">Mail Box</a></li>
                <li><a href="chat.html">Chat</a></li>
                <li><a href="faq.html">FAQ</a></li>
            </ul> -->
        </li>
         
         <li class="">
            <a class="" href="manage-blog.php" aria-expanded="false">
                <i class="fas fa-address-book"></i>
                <span>Blog</span>
            </a>
        </li>

        <li class="">
            <a class="" href="manage-seo.php" aria-expanded="false">
                <i class="fas fa-address-book"></i>
                <span>SEO</span>
            </a>
        </li>

        <li class>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-file"></i>
                <span>Manage Pages</span>
            </a>
            <ul>
                <li><a href="header-setting.php">Header setting</a></li>
                <li><a href="footer-setting.php">Footer Setting</a></li>
                <li><a href="setting.php">Main Setting</a></li>
                <li><a href="logos.php">Logo</a></li>
            </ul>
        </li>


    </ul>
</nav>


<?php include 'includes/top-bar.php';
?>

<div class="main_content_iner ">
    <div class="container-fluid plr_30 body_white_bg pt_30">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="QA_section">
                    <div class="white_box_tittle list_header">
                        <h4>About-us</h4>
                    </div>
                    <?php $select = "SELECT * FROM tbl_about_us";
                    $aboutus = mysqli_query($conn, $select);
                    $data = mysqli_fetch_assoc($aboutus);
                    ?>
                    <div class="col-md-12 col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <ul class="nav nav-pills nav-justified fs-6" id="myTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">About us</button>
                                    </li>


                                </ul>

                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active mt-5" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <form action="" name="settings_from" method="post" enctype="multipart/form-data">
                                            <div class="form-group mt-4 row">
                                                <label for="name" class="col-sm-3 col-form-label">Title :-</label>
                                                <div class="col-sm-9">
                                                    <input class="form-control" type="hidden" name="id" value="<?php echo $data['id']; ?>">
                                                    <input class="form-control" type="text" name="title" value="<?php echo $data['title']; ?>">

                                                </div>
                                            </div>

                                            <div class="form-group mt-4 row">
                                                <label for="img" class="col-sm-3 col-form-label">Image :-</label>
                                                <div class="col-sm-9">
                                                    <div class="fileupload_block">
                                                        <input type="file" name="img" id="fileupload">
                                                        <img style="object-fit:cover;" src="images/about-us/<?php echo $data['image']; ?>" alt="about-us-image" />
                                                        <input type="text" name="alt_tag" id="alt_tag" placeholder="Enter about us image Alternate text" title="Enter about us Alternate text here !" value="<?php echo $data['alt_tag']; ?>" class="form-control" />
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group mt-4 row">
                                                <label for="about_us" class="col-sm-3 col-form-label">Short title :-</label>
                                                <div class="col-sm-9">

                                                    <input class="form-control" type="text" name="small_title" value="<?php echo $data['small_title']; ?>">

                                                </div>
                                            </div>
                                            <div class="form-group mt-4 row">
                                                <label for="about_us" class="col-sm-3 col-form-label">About Us Description :-</label>
                                                <div class="col-sm-9">

                                                    <textarea class="form-control" id="tinymce-example" rows="10" name="description"><?php echo $data['description']; ?></textarea>

                                                </div>
                                            </div>


                                            <div class="form-group mt-4 row">
                                                <div class="col-sm-10">
                                                    <button type="submit" name="about_us_page" class="btn btn-primary"><i class="feather icon-send mr-2"></i>Submit</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End col -->

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    include 'includes/footer.php';
    ?>