<?php
include 'includes/header.php';
// include 'includes/config.php';

date_default_timezone_set('Asia/Calcutta');
?>
<?php
if (isset($_POST['addproduct'])) {

    $name = $_POST['product_name'];
    $category_id = $_POST['category'];
    $Volume = $_POST['Volume'];


    $Visibility = $_POST['Visibility'];
    $description = $_POST['description'];
    $file = $_FILES['img'];
    $imageName = $file['name'];
    $fileTmpPath = $_FILES["img"]["tmp_name"];
    $fileSize = $file['size'];

    // Specify the directory to which you want to save the uploaded file
    $targetDirectory = 'images/products/';

    // Generate a unique name for the file to prevent overwriting
    $newFileName = uniqid() . '_' . $imageName;
    $targetFilePath = $targetDirectory . $newFileName;
    move_uploaded_file($fileTmpPath, $targetFilePath);
    $query = "INSERT INTO tbl_product(category_id,product_name,product_description,product_image,volume_id,visibility_id) 
        VALUES ($category_id,'$name','$description','$imageName',$Volume,$Visibility)";

    $result = mysqli_query($conn, $query);

    if (mysqli_affected_rows($conn) > 0) {
        echo "<script type='text/javascript'>alert('Inserted!');</script>";
        echo '<script>window.location.href = "manage-product.php";</script>';
    } else {
        echo "<script type='text/javascript'>alert('Something went Wrongh!');</script>";
        echo '<script>window.location.href = "manage-product.php";</script>';
    }
}

?>
<!--add-employees -->
<!-- include 'includes/side-bar.php';-->
<?php
$select = "SELECT * FROM tbl_footer_setting WHERE id = 1";
$result = mysqli_query($conn, $select);
$row = mysqli_fetch_assoc($result);
?>
<nav class="sidebar">
    <div class="logo d-flex justify-content-between">
        <a href="index.html"><img src="images/footer/<?php echo $row['logo']; ?>" height="70" width="70" alt="<?php echo $row['alt_tag']; ?>"></a>
        <div class="sidebar_close_icon d-lg-none">
            <i class="ti-close"></i>
        </div>
    </div>
    <ul id="sidebar_menu">
        <li class="">
            <a class="" href="home.php" aria-expanded="false">

                <img src="assets/img/menu-icon/1.svg" alt>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fa fa-users"></i>
                <span>Manage Employee</span>
            </a>
            <ul>
                <li><a href="manage-employee.php">Employees</a></li>
                <li><a href="manage-department.php">Departments</a></li>
                <li><a href="manage-role.php">Roles</a></li>
            </ul>
        </li>
        <li>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-box"></i>
                <span>Manage Products</span>
            </a>
            <ul>
                <li><a href="manage-category.php">Categorys</a></li>
                <!-- <li><a href="manage-department.php">Sub-Categorys</a></li> -->
                <li><a href="manage-product.php">Products</a></li>
            </ul>
        </li>
        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-truck"></i>
                <span>Manage Supplier</span>
            </a>
            <ul>
                <li><a href="manage-supplier.php">Supplier</a></li>
                <li><a href="supplier-product.php">Product</a></li>
            </ul>
        </li>
        <li class>
            <a class="" href="manage-customer.php" aria-expanded="false">
                <i class="fa fa-users"></i>
                <span>Manage Customer</span>
            </a>
            <!-- <ul>
                <li><a href="mail_box.html">Mail Box</a></li>
                <li><a href="chat.html">Chat</a></li>
                <li><a href="faq.html">FAQ</a></li>
            </ul> -->
        </li>
        <li class>
            <a class="" href="manage-inquiry.php" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>Manage Inquiry</span>
            </a>
            <!-- <ul>
                <li><a href="mail_box.html">Mail Box</a></li>
                <li><a href="chat.html">Chat</a></li>
                <li><a href="faq.html">FAQ</a></li>
            </ul> -->
        </li>


        <li class>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-clipboard-list"></i>
                <span>About Us</span>
            </a>
            <ul>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="mission-vission-goal.php">Mission,Vission,Goals</a></li>
                <li><a href="Team.php">Team</a></li>
            </ul>
        </li>

        <li class>
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-address-book"></i>
                <span>Manage FAQs</span>
            </a>
            <ul>
                <li><a href="faqs-customer.php">Customer FAQs</a></li>
                <li><a href="faqs-supplier.php">Supplier FAQs</a></li>
            </ul>
        </li>
          <li class="">
            <a class="" href="contact-us-setting.php" aria-expanded="false">
                <i class="fas fa-address-book"></i>
                <span>Contact Us</span>
            </a>
            <!-- <ul>
                <li><a href="mail_box.html">Mail Box</a></li>
                <li><a href="chat.html">Chat</a></li>
                <li><a href="faq.html">FAQ</a></li>
            </ul> -->
        </li>
         
        <li class="mm-active">
            <a class="" href="manage-blog.php" aria-expanded="false">
                <i class="fas fa-address-book"></i>
                <span>Blog</span>
            </a>
        </li>

        <li class="">
            <a class="has-arrow" href="#" aria-expanded="false">
                <i class="fas fa-file"></i>
                <span>Manage Pages</span>
            </a>
            <ul>
                <li><a href="header-setting.php">Header setting</a></li>
                <li><a href="footer-setting.php">Footer Setting</a></li>
                <li><a href="logos.php">Logo</a></li>
            </ul>
        </li>


    </ul>
</nav>

<?php include 'includes/top-bar.php';
?>

<div class="main_content_iner ">
    <div class="container-fluid plr_30 body_white_bg pt_30">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="QA_section">
                    <div class="white_box_tittle list_header">
                        <h4 class="page-title"><?php if (isset($_GET['edit_id'])) { ?>Edit<?php } else { ?>Add<?php } ?> Blog</h4>

                    </div>
                    <!-- script -->
                    <script type="text/javascript">
                        function OnTitle(txt) {
                            var str = txt.value;

                            var resOld = str.replace(/[&\/\\#,+()$~%.'":*?!@_^`|\[\];=<>{}]/g, ''); //replace special charactor with     blanck space
                            var res = resOld.toLowerCase();

                            var text = " | RnD Technosoft";
                            // document.getElementById("meta_title").value =  txt.value+text;  //create  meta Title

                            var res1 = res.split(" ").join("-"); //replace space with - sign	
                            document.getElementById("page_name").value = res1 + ".php"; //create webpage name

                            // var url="https://www.rndtechnosoft.com/blog/";
                            // document.getElementById("meta_url").value = url+res1+".php";  //create  meta url

                            document.getElementById("meta_canonical").value = url + res1 + ".php"; //create  meta canonical url



                        }

                        function OnWebpageName(txt) {
                            var str = txt.value;

                            var resOld = str.replace(/[&\/\\#,+()$~%'":*?!@_^`|\[\];=<>{}]/g, ''); //replace special charactor with blanck space
                            var res = resOld.toLowerCase();

                            var res1 = res.split(" ").join("-");

                            // var url="https://www.rndtechnosoft.com/blog/";
                            // document.getElementById("meta_url").value = url+res1;  //create  meta url


                        }

                        function OnDesc(txt) {

                            var str = txt.value;
                            document.getElementById("meta_desc").value = txt.value; //create  meta Description

                        }


                        function setImage(val) {
                            var url1 = "https://www.rndtechnosoft.com/admin/images/blog/";
                            var url2 = "Blog-" + Math.floor((Math.random() * 99999) + 1) + "_";

                            var fileName = val.substr(val.lastIndexOf("\\") + 1, val.length); //get browse image name


                            document.getElementById("browse_image").value = url2 + fileName; // add image name to text box


                            document.getElementById("meta_image").value = url1 + url2 + fileName; // add image name to meta_image with comlete URl

                        }

                        function onWebPage() {
                            if (document.getElementById("web_page").checked) {
                                document.getElementById("page_name").readOnly = true;
                            } else {
                                document.getElementById("page_name").readOnly = false;
                            }
                        }
                    </script>


                    <!-- start blog -->
                    <form class="" method="post" enctype="multipart/form-data">
                        <div class="mb-3 row col-12">
                            <div class="mb-3 col-lg-12">
                                <label for="ProductName" class="form-label">Blog Title</label>
                                <input type="text" name="title" id="title" <?php if (isset($_GET['add'])) { ?>onkeyup="OnTitle(this);" <?php } ?> value="<?php if (isset($_GET['edit_id'])) {
                                                                                                                                                                echo $row['title'];
                                                                                                                                                            } ?>" class="form-control" required>

                            </div>

                            <div class="mb-3 col-lg-12">
                                <label for="ProductName" class="form-label">File</label>
                                <input type="text" name="page_name" id="page_name" <?php if (isset($_GET['add'])) { ?>onkeyup="OnWebpageName(this);" <?php } ?> pattern="[a-z0-9._%+-]+\.php" title="Must contain have lowercase letter, use - as special charactor and ednding with .php extension" value="<?php if (isset($_GET['edit_id'])) {
                                                                                                                                                                                                                                                                                                                echo $row['page_name'];
                                                                                                                                                                                                                                                                                                            } ?>" class="form-control" required <?php if (isset($_GET['edit_id'])) {
                                                                                                                                                                                                                                                                                                                                                    echo "readonly";
                                                                                                                                                                                                                                                                                                                                                } ?> readonly>
                            </div>

                            <?php if (isset($_GET['add'])) { ?>
                                <div class="col-lg-12 mb-3">
                                    <input onclick="onWebPage();" type="checkbox" id="web_page" checked /> <label for="web_page"> Readonly Text</label>
                                </div>
                            <?php } ?>

                            <div class="mb-3 col-lg-12">
                                <div class="mb-3 col-lg-12">
                                    <label for="ProductName" class="form-label">Page Type</label>
                                    <input type="text" name="page_type" id="page_type" value="<?php if (isset($_GET['add'])) { ?>blog<?php } ?><?php echo $meta_row['page_type']; ?>" class="form-control" readonly>
                                </div>
                            </div>

                            <div class="mb-3 col-lg-12">
                                <div class="mb-3 col-lg-12">
                                    <label for="ProductName" class="form-label">Blog Description</label>
                                    <textarea  name="sort_desc" id="sort_desc" onkeyup="OnDesc(this);" class="form-control"><?php if(isset($_GET['edit_id'])){echo $row['sort_desc'];}?></textarea>
                                </div>
                            </div>

                            <div class="mb-3 col-lg-12">
                                <label for="ProductImagy" class="form-label">Image </label>
                                <input type="file" class="form-control" id="ProductImagy" aria-describedby="image" name="img">
                            </div>

                            <div class="mb-3 col-lg-12 col-md-12">
                                <label for="Description" class="form-label">Blog Single Description </label>
                                <textarea name="description" class="form-control" rows="5" id="default" style="resize: none; border-color: dark;"></textarea>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" value="product" name="addproduct">Submit</button>

                    </form>
                    <!-- end of form  -->



                </div>
            </div>
        </div>
    </div>
</div>



<?php
include 'includes/footer.php';
?>