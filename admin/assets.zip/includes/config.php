<?php
// error_reporting(0);
ob_start();
session_start();

DEFINE('DB_USER', 'rndtd_trading_user');
DEFINE('DB_PASSWORD', 'Qwaszx@123');
DEFINE('DB_HOST', 'localhost'); //host name depends on server
DEFINE('DB_NAME', 'rndtd_trading_db');
// function ConnectToDatabase()
// {

//     header("Content-Type: text/html;charset=UTF-8");

//     $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

//     if (!$conn) {
//         die("connection lost" . mysqli_connect_errno());
//     }

//     return $conn;
// }


header("Content-Type: text/html;charset=UTF-8");

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if (!$conn) {
    die("connection lost" . mysqli_connect_errno());
}

mysqli_set_charset($conn, 'utf8');

