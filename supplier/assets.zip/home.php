<?php
include 'includes/header.php';
include 'includes/side-bar.php';
include 'includes/top-bar.php';

?>
<div class="main_content_iner ">
    <div class="container-fluid plr_30 body_white_bg pt_30">
        <div class="row justify-content-center" id='main'>
            <div class="col-lg-12">
                <div class="single_element">
                    <div class="quick_activity">
                        <div class="">
                            <!-- count class for count -->
                            <div class="col-12">
                                <div class="quick_activity_wrap ">
                                    <div class="single_quick_activity <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?>">
                                        <h4>USERS</h4>
                                        <h3><span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALUSER FROM tbl_user';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALUSER'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    <div class="single_quick_activity <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?> ">
                                        <h4>DEPARTMENTS</h4>
                                        <h3> <span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALUSER FROM tbl_dept';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALUSER'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    <div class="single_quick_activity <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?>">
                                        <h4>ROLES</h4>
                                        <h3><span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALUSER FROM tbl_role';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALUSER'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    <div class="single_quick_activity <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?>">
                                        <h4>Customer</h4>
                                        <h3><span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as customer FROM tbl_customer';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['customer'], 2, '.', '');
                                                            echo $row['customer'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="quick_activity_wrap">
                                <div class="single_quick_activity <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?>">
                                        <h4>PRODUCTS</h4>
                                        <h3><span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as products FROM tbl_product';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['products'], 2, '.', '');
                                                            echo $row['products'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    <div class="single_quick_activity <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?>">
                                        <h4>SUPPLIER</h4>
                                        <h3><span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALSUPPLIER FROM tbl_supplier';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALSUPPLIER'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    <div class="single_quick_activity <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?>">
                                        <h4>INQUIRY</h4>
                                        <h3> <span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALINQUERY FROM tbl_inquiry';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALINQUERY'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    
                                    <div class="single_quick_activity  <?php if($_SESSION['dept_id'] != 1){ echo "d-none"; } ?>">
                                        <h4>SUPPLIER REQUEST</h4>
                                        <h3> <span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALREQUEST FROM tbl_supplier_request';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALREQUEST'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                   
                                </div>
                            </div>
                            
                            <div class="col-12">
                                <div class="quick_activity_wrap">
                                     
                                    <div class="single_quick_activity">
                                        <h4>PENDING</h4>
                                        <h3> <span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALREQUEST FROM tbl_supplier_request WHERE status_id=1';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALREQUEST'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    
                                      <div class="single_quick_activity">
                                        <h4>IN PROCESS </h4>
                                        <h3> <span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALREQUEST FROM tbl_supplier_request WHERE status_id=2';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALREQUEST'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                    
                                     <div class="single_quick_activity">
                                        <h4>VERIFIED</h4>
                                        <h3> <span class=""><?php
                                                            $SelectUser = 'SELECT COUNT(*) as TOTALREQUEST FROM tbl_supplier_request WHERE status_id=4';
                                                            $result = mysqli_query($conn, $SelectUser);
                                                            $row = mysqli_fetch_assoc($result);
                                                            // echo number_format((float)$row['TOTALUSER'], 2, '.', '');
                                                            echo $row['TOTALREQUEST'];
                                                            ?></span> </h3>
                                        <p></p>
                                    </div>
                                </div>
                            </div>    
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include 'includes/footer.php';
?>