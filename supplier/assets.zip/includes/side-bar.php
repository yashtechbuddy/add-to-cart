<?php
$select = "SELECT * FROM tbl_footer_setting WHERE id = 1";
$footerl = mysqli_query($conn, $select);
$sidebarlogo = mysqli_fetch_assoc($footerl);
?>
<nav class="sidebar">
    <div class="logo d-flex justify-content-between">
        <a href="index.html"><img src="./images/footer/<?php echo $sidebarlogo['logo']; ?>" height="70" width="70" alt="<?php echo $sidebarlogo['alt_tag']; ?>"></a>
        <div class="sidebar_close_icon d-lg-none">
            <i class="ti-close"></i>
        </div>
    </div>
    <ul id="sidebar_menu">
        
         <li class="">
            <a class="" href="home.php" aria-expanded="false">
              <i class="fa-solid fa-house"></i>
                <span>Dashboard</span>
            </a>
        </li>
        

        <li class="">
            <a class="" href="inquerys.php" aria-expanded="false">
                <i class="fa-solid fa-clipboard-question"></i>
                <span>Manage Inqueys</span>
            </a>
        </li>

         <li class="">
            <a class="" href="inquerys.php" aria-expanded="false">
               <i class="fa-brands fa-product-hunt"></i>
                <span>Your Products</span>
            </a>
        </li>
  
    </ul>
</nav>